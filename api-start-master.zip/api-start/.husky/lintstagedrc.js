module.exports = {
  "*.js": ["npm run lint"]
  // ... 批量添加lint相关的npm命令
}